#!/usr/bin/env python3
"""Quick test to verify fraud agent is working"""

import asyncio
import os
from dotenv import load_dotenv

load_dotenv()

async def test_fraud_agent():
    """Test fraud agent with a simple message"""
    print("Testing Fraud Risk Agent...")
    print(f"Agent ID: {os.getenv('FRAUD_RISK_AGENT_ID')}")
    print(f"Endpoint: {os.getenv('AZURE_AI_PROJECT_ENDPOINT')}")
    
    from fraud_risk_agent import analyze_with_fraud_agent
    
    # Test message
    message = "Your DT Logistics parcel requires a $5 delivery fee. Pay now at http://fake-link.com/pay"
    sender = "+61400123456"
    
    print(f"\nAnalyzing: {message}")
    print(f"Sender: {sender}\n")
    
    try:
        analysis = await analyze_with_fraud_agent(message, sender)
        print(f"✅ SUCCESS!")
        print(f"   Threat Level: {analysis.threat_level.value}")
        print(f"   Fraud Category: {analysis.fraud_category.value}")
        print(f"   Confidence: {analysis.confidence_score:.1%}")
        print(f"   Risk Indicators: {len(analysis.risk_indicators)}")
        print(f"\nFull Analysis:")
        from fraud_risk_agent import fraud_risk_agent
        print(fraud_risk_agent.format_analysis_report(analysis))
    except Exception as e:
        import traceback
        print(f"❌ FAILED: {e}")
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_fraud_agent())
